"use strict";
var JwtStrategy = require("passport-jwt").Strategy;
var ExtractJwt = require("passport-jwt").ExtractJwt;
const passport = require("passport");
const secret = "abcd1234";
const User = require('../Models/adminModel');
const Restaurant = require('../Models/RestaurantModel');

function auth() {
    console.log("auth")
    var opts = {
        jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
        secretOrKey: secret
    };
    passport.use(
        new JwtStrategy(opts, (jwt_payload, callback) => {
            console.log("asdasd")
            console.log(jwt_payload)
            if("CustomerId" in jwt_payload){
                let CustomerId = jwt_payload.CustomerId;
                User.findOne({CustomerId:CustomerId}, (err, results) => {
                    if (err) {
                        return callback(err, false);
                    }
                    if (results) {
                        callback(null, results);
                    }
                    else {
                        callback(null, false);
                    }
                });
            }else if("RestaurantId" in jwt_payload){
                let RestaurantId = jwt_payload.RestaurantId;
                Restaurant.findOne({RestaurantId:RestaurantId}, (err, results) => {
                    if (err) {
                        return callback(err, false);
                    }
                    if (results) {
                        callback(null, results);
                    }
                    else {
                        callback(null, false);
                    }
                });
            }else{
                console.log(jwt_payload)
                return callback(null, false);
            }
            
        })
    )
}

exports.auth = auth;
exports.checkAuth = passport.authenticate("jwt", { session: false });
